package com.example.asus.virtualeyedoc;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import static com.example.asus.virtualeyedoc.Main2Activity.Name;
import static com.example.asus.virtualeyedoc.Main2Activity.Pass;
import static com.example.asus.virtualeyedoc.Main2Activity.n;
import static com.example.asus.virtualeyedoc.Main2Activity.p;
import static com.example.asus.virtualeyedoc.R.id.editText_Pass;

public class game6 extends AppCompatActivity {


    DatabaseHelper db;
    Button btnWrong;
    Button btnRight;
    Button btnShow;
    TextView tv;
    TextView tv1;
    EditText editID;
    String name;
    String pass;
    Main2Activity m;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game6);

        final DatabaseHelper obj = new DatabaseHelper(getApplicationContext());
        btnWrong = (Button) findViewById(R.id.button_wrong);
        btnRight = (Button) findViewById(R.id.button_right);

        prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        pass = (prefs.getString(Pass, n));
        name = (prefs.getString(Name, p));
        final String s = name;
        final String t = pass;
        final String sc = "6";
        Right();


        btnWrong.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i1 = new Intent(game6.this, game6_1.class);

                        startActivity(i1);
                    }
                }
        );
    }


    public  void Right() {
        btnRight.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(game6.this, game7.class);

                        startActivity(i);
                    }
                }
        );
    }

}
