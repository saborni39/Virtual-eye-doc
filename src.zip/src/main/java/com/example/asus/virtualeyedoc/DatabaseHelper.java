package com.example.asus.virtualeyedoc;

/**
 * Created by ASUS on 17/03/2016.
 */
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    Context context;
    public static final String DATABASE_NAME = "Progress.db";
    public static final String Table_Prog = "Progress_table";
    public static final String Id = "ID";
    public static final String Range = "Range";
    public static final String Password = "PASS";

    private static final int DATABASE_VERSION = 2;


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String creating_table = "CREATE TABLE " + Table_Prog  + " ("
                + Id + " INTEGER PRIMARY KEY,"
                + Range + " TEXT"
                + " )";

        db.execSQL(creating_table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS "+Table_Prog);

        onCreate(db);

    }

    public void addNewPerson(AddPerson Temp) {

        SQLiteDatabase d = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(Range, Temp.getName());
        //values.put(Password, Temp.getPass());
      //  values.put(Range, Temp.getScore());
        d.insert("Progress_table", null, values);

        //db.close();

    }
    public void update(AddPerson Temp,String pa){
        SQLiteDatabase b=this.getWritableDatabase();
        ContentValues values = new ContentValues();

       // values.put(Password, Temp.getPass());
        b.update("Progress_table",values," NAME = "+pa,null);


    }

    public String[] getAllDataFromTable() {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor res = db.rawQuery( "select * from " + Table_Prog + ";", null);
        res.moveToFirst();

        String p[]=new String[res.getCount()];
        if (res.moveToFirst()) {
            int i = 0;

            do {


                p[i] = "Your Eye Power : " + res.getString(res.getColumnIndex(Range + ""));


                i = i + 1;
            } while (res.moveToNext());
        }
        return p;


    }

}


