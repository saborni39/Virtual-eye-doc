package com.example.asus.virtualeyedoc;

/**
 * Created by ASUS on 28/03/2016.
 */
public class AddPerson {
    int id;
    String name;
    String password;
    String score;

    public AddPerson(String s, String sc, String t){

    }

    public AddPerson(int Id,String Name){

        this.id=Id;
        this.name=Name;

    }

    public AddPerson(String Name){

        this.name=Name;

    }
    public int getMy_id() {
        return id;
    }
    public void setMy_id(int iD) {
        this.id = iD;
    }

    public void setId(int ID) {
        this.id = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = Name;
    }
}

