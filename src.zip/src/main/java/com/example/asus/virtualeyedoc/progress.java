package com.example.asus.virtualeyedoc;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

public class progress extends AppCompatActivity {

    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        final DatabaseHelper ob = new DatabaseHelper(getApplicationContext());

        tv=(TextView)findViewById(R.id.Show);

        String s = "";
        String[] rec_data = ob.getAllDataFromTable();

        for (int i = 0; i < rec_data.length; i++) {
            s = s + rec_data[i] + "\n\n";
        }
        tv.setText(s);

    }

}
