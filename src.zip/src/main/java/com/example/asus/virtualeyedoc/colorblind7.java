package com.example.asus.virtualeyedoc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class colorblind7 extends AppCompatActivity {
    Button btnWrong;
    Button btnRight;
    Button btnShow;
    ImageButton btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colorblind7);
        btnWrong = (Button) findViewById(R.id.button_wrong);
        btnRight = (Button) findViewById(R.id.button_right);


        configureImageButton();
        btnWrong.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent k = new Intent(colorblind7.this, colorblind8.class);
                        startActivity(k);
                    }
                }
        );

        btnRight.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(colorblind7.this, colorblind8.class);
                        startActivity(i);
                    }
                }
        );

    }
    private void configureImageButton(){
        btn = (ImageButton) findViewById(R.id.img_btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn = (ImageButton) findViewById(R.id.img_btn1);
                btn.setBackgroundResource(R.drawable.b_8);



            }
        });
    }
}
