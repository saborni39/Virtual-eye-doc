package com.example.asus.virtualeyedoc;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class colorblind3 extends AppCompatActivity {
    Button btnWrong;
    Button btnRight;
    Button btnShow;
    ImageButton btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitvity_color4);
        btnWrong = (Button) findViewById(R.id.button_wrong);
        btnRight = (Button) findViewById(R.id.button_right);


        configureImageButton();
        btnWrong.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent k = new Intent(colorblind3.this, colorblind4.class);
                        startActivity(k);
                    }
                }
        );

        btnRight.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(colorblind3.this, colorblind4.class);
                        startActivity(i);
                    }
                }
        );

    }

    private void configureImageButton(){
        btn = (ImageButton) findViewById(R.id.img_btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn = (ImageButton) findViewById(R.id.img_btn1);
                btn.setBackgroundResource(R.drawable.b_4);



            }
        });
    }




}
