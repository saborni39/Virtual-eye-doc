package com.example.asus.virtualeyedoc;

import junit.framework.TestCase;

/**
 * Created by Shaborni on 4/16/2016.
 */
public class colorblindTest extends TestCase {

    public void testOnCreate() throws Exception {

    }
}