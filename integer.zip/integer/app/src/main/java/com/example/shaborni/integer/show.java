package com.example.shaborni.integer;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class show extends AppCompatActivity {
    static show INSTANCE;
    Integer inc=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        INSTANCE=this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        Button btn=(Button) findViewById(R.id.b_1);
        final EditText et=(EditText)findViewById(R.id.e_1);
        final Integer j=12;
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Intent k = new Intent(show.this, Image_button.class);
                k.putExtra("user_input",et.getText().toString());
               // Intent i = new Intent(show.this, Image_button.class);
               // i.putExtra("user_cmp",et.getText().toString());
//                  i.putExtra("cmp", j);
               startActivity(k);
                //startActivity(i);



            }
        });

    }

    public static show getActivityInstance()
    {
        return INSTANCE;
    }

    public Integer getData()
    {
        return this.inc;
    }

}
