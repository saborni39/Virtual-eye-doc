package com.example.shaborni.integer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.content.Intent;

public class Image_button extends AppCompatActivity {
    Integer inc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String s;
        setContentView(R.layout.activity_image_button);
        TextView txt= (TextView)findViewById(R.id.textView2);
        TextView txt1= (TextView)findViewById(R.id.textView);

        s=getIntent().getExtras().getString("user_input");
        //txt.setText(R.string.app_name);
        String s1="12";
        inc=show.getActivityInstance().getData();
        boolean correct="12".equals(s);
             if (correct==true){
                 txt.setText(R.string.cmp);
                 txt1.setText( String.format("Data from first activity is%d", inc));
             }
             else{
                 txt.setText(R.string.cmp1);
             }
    }
}
